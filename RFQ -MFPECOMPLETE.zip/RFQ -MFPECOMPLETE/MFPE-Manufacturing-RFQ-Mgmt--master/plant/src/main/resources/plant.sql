insert into part values(1,'Engine','220cc',9);
insert into part values(2,'Gearbox','4g',10);
insert into part values(3,'Tires','CEATE',8);

insert into demand values(1,100,'2022-03-10',1);
insert into demand values(2,100,'2022-03-20',2);
insert into demand values(3,100,'2022-03-30',3);

insert into reorderrules values(1,1,20,10,13,1);
insert into reorderrules values(2,2,20,10,20,2);
insert into reorderrules values(3,3,20,10,20,3);