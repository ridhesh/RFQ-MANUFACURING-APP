package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.rfq;

public interface rfqRepository extends JpaRepository<rfq,Integer> {

}
