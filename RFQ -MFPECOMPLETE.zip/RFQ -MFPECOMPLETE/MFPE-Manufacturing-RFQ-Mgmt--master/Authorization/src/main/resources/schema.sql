create table userrecord(
id int not null,
username varchar(25) not null,
password varchar(25) not null,
primary key (id)
);