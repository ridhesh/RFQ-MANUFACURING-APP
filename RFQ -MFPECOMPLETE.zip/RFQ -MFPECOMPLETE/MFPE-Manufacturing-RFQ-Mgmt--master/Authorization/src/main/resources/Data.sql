insert into userrecord values(1,'12334','hemanth');
insert into userrecord values(2,'1232','farhan');