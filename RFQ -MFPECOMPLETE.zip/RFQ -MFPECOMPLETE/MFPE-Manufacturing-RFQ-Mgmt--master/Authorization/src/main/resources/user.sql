insert into userrecord values(1,'hemanth','123');
insert into userrecord values(2,'farhan','123');